import * as React from 'react';
import "./ChatLoader.css";


export default function ChatLoader() {

	return (
		<>
			
				<div class="loader"></div>
				
		</>
	);
}
